'''
Created on 16.11.2017

@author: neroon
'''

from mdm_dataPreProcess import *
from mdm_config import *
import tkinter
from shutil import *
import platform

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: class mdm_gui
Input: tkinter.Frame 
Output: none
description: graphical user interface using tkinter 

@author: Marcus Landschulze
'''
class mdm_gui(tkinter.Frame):
    
    mining_res = []
    keywords = []
    isrunning = False
    ismining = False
    issaving = False
    mining_count = 0
    mining_counter_max = 0
    file_text = []
    filepath = []
    key_list = []
    pdf2text = []
    browser = []
    pdfreader = []
    project = []
    
    def __init__(self,master=None):
        tkinter.Frame.__init__(self, master)
        self.pack(fill="both", expand=True)
        self.createWidgets()
        
        
        
    def createWidgets(self):

        try:
            [self.filepath, self.key_list, self.file_text, self.pdf2text, self.browser, self.pdfreader, self.project] = readConfigMain()
        except(TypeError) as err:
            print('No stem_config.cfg file found. Please check manual\n%s'%err.args[1])


        self.winfo_toplevel().title("STeM  scientific text mining         V0.1b               (C)2018 by Dr. M. Landschulze")
        self.winfo_toplevel().minsize(width=800,height=430)
        
        # Control
        self.control = tkinter.LabelFrame(self,text='Control',padx=5,pady=5)
        self.control.pack(fill="both",expand=False)
        self.start = tkinter.Button(self.control,text="Check",command=self.startMining)
        self.start.pack(side="left", anchor="center")
        self.clear = tkinter.Button(self.control,text="Clear",command=self.clearMining)
        self.clear.pack(side="left", anchor="center")
        self.projectLB = tkinter.Label(self.control,text="   Project: %s"%self.project)
        self.projectLB.pack(side="left", anchor="center")
        self.mining = tkinter.Button(self.control,text="Mining",command=self.miningTextData)
        self.mining.pack(side="right", anchor="center")
        self.mdmconfig = tkinter.Button(self.control,text="Config",command=self.configMdm)
        self.mdmconfig.pack(side="right", anchor="center")
        
        
        # Key words
        self.keys = tkinter.LabelFrame(self,text='Keywords',padx=5,pady=5)
        self.keys.pack(fill="both",expand=False)
        while len(self.key_list) > 4:
            self.key_list.pop(len(self.key_list)-1)
            
        if len(self.key_list) == 4:
            self.keyword1 = tkinter.Label(self.keys,text=self.key_list[0]+', '+self.key_list[1]+', '+self.key_list[2]+', '+self.key_list[3])
        if len(self.key_list) == 3:
            self.keyword1 = tkinter.Label(self.keys,text=self.key_list[0]+', '+self.key_list[1]+', '+self.key_list[2])
        if len(self.key_list) == 2:
            self.keyword1 = tkinter.Label(self.keys,text=self.key_list[0]+', '+self.key_list[1])
        if len(self.key_list) == 1:
            self.keyword1 = tkinter.Label(self.keys,text=self.key_list[0])
            
        self.keyword1.pack(side="left", anchor="center")
        self.help = tkinter.Button(self.keys,text="Help",command=self.showHelp)
        self.help.pack(side="right", anchor="center")


        # Results
        self.results = tkinter.LabelFrame(self,text='Results',padx=5,pady=5)
        self.results.pack(fill="both",expand=True)
        self.mining_text = tkinter.Text(self.results,wrap="word")
        self.mining_text.config(width=106, height=15)
        self.res_sb = tkinter.Scrollbar(self.mining_text)
        self.res_sb.pack(fill="y", side="right")
        self.mining_text["yscrollcommand"] = self.res_sb.set
        self.res_sb["command"] = self.mining_text.yview
        self.mining_text.tag_config("ug", underline=True, foreground="gray")
        self.mining_text.tag_config("r", underline=False, foreground="red")
        self.mining_text.pack(side="top",anchor="center",fill="both", expand=True)
        help_text = showHelp()
        self.mining_text.delete(1.0,"end")
        self.mining_text.insert(1.0,str(help_text))
        
        self.next = tkinter.Button(self.results,text="Next",command=self.nextMiningRes)
        self.next.pack(side="right", anchor="center")
        self.previous = tkinter.Button(self.results,text="Previous",command=self.previousMiningRes)
        self.previous.pack(side="right", anchor="center")
        self.store = tkinter.Button(self.results,text="Store",command=self.storePaper)
        self.store.pack(side="left", anchor="center")
        self.delete = tkinter.Button(self.results,text="Delete",command=self.deletePaper)
        self.delete.pack(side="left", anchor="center")
        # Status
        self.status = tkinter.LabelFrame(self,text='Status',padx=5,pady=5)
        self.status.pack(fill="both",expand=False)
        self.label = tkinter.Label(self.status,text="...")
        self.label.pack(side="left", anchor="center")

    def showHelp(self):
        if self.issaving == False:
            help_text = showHelp()
            self.mining_text.delete(1.0,"end")
            self.mining_text.insert(1.0,str(help_text))
        
        return 0

        
    def browserSearch(self):
        if self.mining_counter_max > 0:
            search = ''.join(str(e+' ') for e in self.mining_res[self.mining_count][0][1])
            os.system('%s -search "%s"'%(self.browser,search))
        else:
            self.browserBT.destroy()
            self.pdfreaderBT.destroy()
            
        self.label["text"] = "..."
        return 0
    
    def pdfread(self):
        if self.mining_counter_max > 0:
            os.system('%s %s/check/%s.pdf'%(self.pdfreader,self.filepath,self.mining_res[self.mining_count][0][2]))
        else:
            self.browserBT.destroy()
            self.pdfreaderBT.destroy()

        self.label["text"] = "..."
        return 0
        
        
    def miningTextData(self):
        kappa_res = []
        mining_res = []
        processtime = []
        if self.ismining == False and self.issaving == False:
            self.ismining = True
            [kappa_res, mining_res, processtime] = mainLoopTM()
            self.label["text"] = "Text mining finished. Time: %.2f sec."%processtime
            if platform.system() == 'Linux':
                fhr = open(self.filepath+'/.work/miningStat.txt','r')
            if platform.system() == 'Windows':
                fhr = open(self.filepath+'/work/miningStat.txt','r')
            stat_txt = fhr.read()
            fhr.close()
            
            if len(mining_res) > 0:
                self.mining_text.delete(1.0,"end")
                self.mining_text.insert("end","Data mining completed\n\nValues are:\n\n"+str(mining_res))
                self.mining_text.insert("end","\n\nMining statistics\n\nValues are:\n\n"+stat_txt)
            else:
                self.mining_text.delete(1.0,"end")
                self.mining_text.insert("end","No match found!\nPlease select different key words")
            
        return 0    
        
    def storePaper(self):
        self.label["text"] = "..."
        if len(self.mining_res) > 0:
            move(self.filepath+'/check/'+self.mining_res[self.mining_count][0][2]+'.pdf',self.filepath+'/pdf/'+self.mining_res[self.mining_count][0][2]+'.pdf')
            move(self.filepath+'/check/'+self.mining_res[self.mining_count][0][2]+'.txt',self.filepath+'/texts/'+self.mining_res[self.mining_count][0][2]+'.txt')
            self.mining_res.pop(self.mining_count)
            self.mining_counter_max -= 1
            if self.mining_counter_max == self.mining_count:
                self.mining_count -= 1
            self.mining_text.delete(1.0,"end")
            self.plotMiningText(self.mining_count)
        return 0
    
    def deletePaper(self):
        self.label["text"] = "..."
        if len(self.mining_res) > 0:
            os.remove(self.filepath+'/check/'+self.mining_res[self.mining_count][0][2]+'.pdf')
            os.remove(self.filepath+'/check/'+self.mining_res[self.mining_count][0][2]+'.txt')
            self.mining_res.pop(self.mining_count)
            self.mining_counter_max -= 1
            if self.mining_counter_max == self.mining_count:
                self.mining_count -= 1
            self.mining_text.delete(1.0,"end")
            self.plotMiningText(self.mining_count)
        
        return 0    
        
    def configMdm(self):
        if self.issaving == False:
            conf = readConfigMain()
            self.issaving = True
            if conf == 0:
                self.label["text"] = "Corrupted config file! Please check the entries and restart program"
    
            self.mining_text.delete(1.0,"end")
            self.mining_text.insert(1.0,str(self.file_text))
            self.save_conf = tkinter.Button(self.control,text="Save config",command=self.configMdmSave)
            self.save_conf.pack(side="right", anchor="center")
            if self.mining_counter_max > 0:
                self.browserBT.destroy()
                self.pdfreaderBT.destroy()
        
        return 0    

    def configMdmSave(self):
        
        text = self.mining_text.get(1.0,"end")
        saveConfigMain(text)
        [self.filepath,self.key_list, self.file_text, self.pdf2text, self.browser, self.pdfreader, self.project] = readConfigMain()
        if len(self.key_list) < 3:
            self.label["text"] = "key-word list is less than 3, but should be 3 or 4!"
            return 0
            
        self.save_conf.destroy()
        if len(self.key_list) == 4:
            self.keyword1["text"] = self.key_list[0]+', '+self.key_list[1]+', '+self.key_list[2]+', '+self.key_list[3]
        if len(self.key_list) == 3:
            self.keyword1["text"] = self.key_list[0]+', '+self.key_list[1]+', '+self.key_list[2]
        
        self.mining_text.delete(1.0,"end")
        self.projectLB["text"] = "   Project: %s"%self.project
        self.label["text"] = "saved config-file"
        self.issaving = False
        return 0
        
    def startMining(self):
        if self.isrunning == False and self.issaving == False:
            self.label["text"] = "Running"
            self.mining_text.delete(1.0,"end")
            self.isrunning = True
            self.mining_res = mainLoopCheck()
            
            self.mining_counter_max = len(self.mining_res)
            if  self.mining_counter_max > 0:
                self.plotMiningText(self.mining_count)
            else:
                self.label["text"] = "..."

            if self.mining_counter_max > 0:
                self.browserBT = tkinter.Button(self.results,text="Search web",command=self.browserSearch)
                self.browserBT.pack(side="left", anchor="center")
                self.pdfreaderBT = tkinter.Button(self.results,text="PDF read",command=self.pdfread)
                self.pdfreaderBT.pack(side="left", anchor="center")

        
        return 0

    def clearMining(self):
        if self.issaving == False:
            self.label["text"] = "cleared results"
            self.isrunning = False
            self.ismining = False
            self.mining_text.delete(1.0,"end")
            self.mining_res = []
            self.mining_count = 0
            if hasattr(self,'browserBT'):
                self.browserBT.destroy()
                self.pdfreaderBT.destroy()

    def plotMiningText(self,item):
        
        if len(self.mining_res) > 0:
            self.mining_text.insert("end","File name:\n\n","ug")
            self.mining_text.insert("end",self.mining_res[item][0][2])
            self.mining_text.insert("end","\n\nImportance of the paper:\n\n","ug")
            self.mining_text.insert("end",self.mining_res[item][0][0])
            major_keywordsintext = sorted(list(set(self.mining_res[item][0][1]).intersection(self.key_list)))
            if len(major_keywordsintext) < 3:
                self.mining_text.insert("end","\nWeak major-keyword correlation may cause unreliable result\n","r")
                if len(major_keywordsintext) == 0:
                    self.mining_text.insert("end","Zero keywords can be a result of a scanned text\n","r")
                    
            self.mining_text.insert("end","\n\nFound keywords:\n\n","ug")
            self.mining_text.insert("end",self.mining_res[item][0][1])
            self.mining_text.insert("end","\n")
            self.label["text"] = "Check mining finished. Time: %.2f sec. (%d/%d)"%(self.mining_res[self.mining_count][0][3],self.mining_count+1,len(self.mining_res))
        
        return 0

    def nextMiningRes(self):
        if self.mining_count < (self.mining_counter_max-1):
            self.mining_count += 1
            self.mining_text.delete(1.0,"end")
            self.plotMiningText(self.mining_count)
        return 0
        
    def previousMiningRes(self):
        if self.mining_count > 0:
            self.mining_count -= 1
            self.mining_text.delete(1.0,"end")
            self.plotMiningText(self.mining_count)
        return 0
        

