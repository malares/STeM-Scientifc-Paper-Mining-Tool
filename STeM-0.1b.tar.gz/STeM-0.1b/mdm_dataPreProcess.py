'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017

@author: Marcus Landschulze
'''
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from collections import Counter
import os
import time
import threading
from mdm_config import *


#text_filepath = filepath+'texts/' 
#text_filename = filepath+'test.txt'
#res_filename = filepath+'result.txt'
#dm_filename = filepath+'dm_result.txt'


 
err_code = [] 


'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: calcDataWords
Input: key_list, res1, res2, res3, [res4] = keyword list, results for n keywords in a single document (n = 3 or 4) 
Output: dm_cname, dm_cvalue = datamining cross key, count of cross key
description: cross correlation of the key-words res1-res4 to find similar words. key_list is only used for len()

@author: Marcus Landschulze
'''
def calcDataWords(key_list, res1, res2, res3, res4=[]):
    
    data_1 = sorted(list(set(res1).intersection(res2)))
    data_2 = sorted(list(set(res1).intersection(res3)))
    data_3 = sorted(list(set(res2).intersection(res3)))
    if len(key_list) > 3:
        data_4 = sorted(list(set(res1).intersection(res4)))
        data_5 = sorted(list(set(res2).intersection(res4)))
        data_6 = sorted(list(set(res3).intersection(res4)))
        dm_cname = [data_1, data_2, data_3, data_4, data_5, data_6]
    else:
        dm_cname = [data_1, data_2, data_3]
            
    data_1_value = Counter(data_1)
    dm_cvalue_1 = list(data_1_value.values())
    data_2_value = Counter(data_2)
    dm_cvalue_2 = list(data_2_value.values())
    data_3_value = Counter(data_3)
    dm_cvalue_3 = list(data_3_value.values())
    if len(key_list) > 3:
        data_4_value = Counter(data_4)
        dm_cvalue_4 = list(data_4_value.values())
        data_5_value = Counter(data_5)
        dm_cvalue_5 = list(data_5_value.values())
        data_6_value = Counter(data_6)
        dm_cvalue_6 = list(data_6_value.values())

        dm_cvalue = [dm_cvalue_1, dm_cvalue_2, dm_cvalue_3, dm_cvalue_4, dm_cvalue_5, dm_cvalue_6]
    else:
        dm_cvalue = [dm_cvalue_1, dm_cvalue_2, dm_cvalue_3]

    return [dm_cname, dm_cvalue]

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: getNouns
Input:  data = text tokens list
Output: result = nouns of the data
description: collecting nouns from the data tokens

@author: Marcus Landschulze
'''
def getNouns(data):
    tagged = nltk.pos_tag(data) # select only subjective, names 

    result=[]
    for t in range(0,int(len(tagged)),1): 
#        if tagged[t][1] == 'NN' or tagged[t][1] == 'NNS' or tagged[t][1] == 'NNP' or tagged[t][1] == 'NNPS':
        if tagged[t][1] == 'NN' or tagged[t][1] == 'NNP':
            result.append(tagged[t][0])
    
    return result

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: getDataWords
Input:  text, key = text token, keyword
Output: result = 3 nouns left and right of the keyword
description: collecting the 3 nouns left and right of the keyword

@author: Marcus Landschulze
'''
def getDataWords(text, key):
    
    c = nltk.ConcordanceIndex(text, key = lambda s: s.lower())
    res_tokens_lowlowlow = []
    res_tokens_lowlow = []
    res_tokens_low = []
    res_tokens_high = []
    res_tokens_highhigh = []
    res_tokens_highhigh = []
    res_tokens_highhighhigh = []
    try:
        res_tokens_lowlowlow = ([text.tokens[offset-3] for offset in c.offsets(key)])
        res_tokens_lowlow = ([text.tokens[offset-2] for offset in c.offsets(key)])
        res_tokens_low = ([text.tokens[offset-1] for offset in c.offsets(key)])
        res_tokens_high = ([text.tokens[offset+1] for offset in c.offsets(key)])
        res_tokens_highhigh = ([text.tokens[offset+2] for offset in c.offsets(key)])
        res_tokens_highhighhigh = ([text.tokens[offset+3] for offset in c.offsets(key)])
    except(IndexError):
        err_code.append('Index error')
        
    result = list(res_tokens_lowlowlow+res_tokens_lowlow+res_tokens_low+res_tokens_high+res_tokens_highhigh+res_tokens_highhighhigh)
    wnl = nltk.WordNetLemmatizer()
    result = [wnl.lemmatize(t) for t in result] 
        
    result = getNouns(result)    

    return result

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: removeKeyListFromData
Input:  data, key_list = text tokens, keywords
Output: data = text tokens without keywords
description: removes the keywords from the text token list

@author: Marcus Landschulze
'''
def removeKeyListFromData(data, key_list):

    try:
        for i in reversed(range(len(data))):
            if data[i]==key_list[0]: data.pop(i)        
            if data[i]==key_list[1]: data.pop(i)        
            if data[i]==key_list[2]: data.pop(i)  
            if len(key_list) > 3:
                if data[i]==key_list[3]: data.pop(i)
                  
    except(IndexError) as e:
        err_code.append('removeKeyListFromData: '+e.args[0]+'\n')
    return data

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: removePaperKeywords
Input:  data = text token list
Output: data = text token list without typical paper keywords
description: remove typical paper words 

@author: Marcus Landschulze
'''
def removePaperKeywords(data):
    
    paper_keys = ['abstract','figure','fig','introduction','conclusion','appendix','equation','reference','table','note','study','show','number']
    
    rem = []
    for rem in list(set(data).intersection(paper_keys)):
        data.remove(rem)
    
    return data

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: reduceDataList
Input: data, cnum = text token list, word counts > cnum 
Output: result = text token with word counts > cnum
description: remove of words with word-counts > cnum

@author: Marcus Landschulze
'''
def reduceDataList(data, cnum):
    r_name = Counter(data)
    r_count = list(r_name.values())
    
    result=[]
    i = 0
    for t in r_name:
        if r_count[i] > cnum:
            for j in range(0,r_count[i],1):
                result.append(t) 
        i = i + 1
    
    return result


'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: saveMiningRaw
Input: filename, kappa_raw 
Output: none
description: save the kappa values to a file. The file is used as a keyword list during checking 

@author: Marcus Landschulze
'''
def saveMiningRaw(filename,kappa_raw):
    
    kappa = str()
    fhw = open(filename,'w')
    for i in range(len(kappa_raw)): kappa = kappa+' '+kappa_raw[i]
    print(kappa,file=fhw)
    fhw.close()
    
    return 0

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: dataPreProc
Input: text_filename, key_list, cnum = text filename, keyword list, word count 
Output: res1,res2,res3,[res4] = resulting nouns
description: text pre-processing such as: remove all stopwords, keywords, paper keywords...

@author: Marcus Landschulze
'''
def dataPreProc(text_filename,key_list,cnum):
    
    dm_stopwords = []
    fh = open(text_filename)
    raw = fh.read()
    fh.close()
    
    raw = raw.lower()
    token = word_tokenize(raw)
    # remove all stopwords -> result is in text
    dm_stopwords = stopwords.words('english') 
    token = [w for w in token if w not in dm_stopwords]
    token = [w for w in token if len(w) >2] # more than 2 charcters

    text = nltk.Text(token)
    res1 = sorted(getDataWords(text, key_list[0]))
    res2 = sorted(getDataWords(text, key_list[1]))
    res3 = sorted(getDataWords(text, key_list[2]))
    if len(key_list) > 3:
        res4 = sorted(getDataWords(text, key_list[3]))
        
    
    # remove key-word list from the data
    res1 = removeKeyListFromData(res1, key_list)
    res2 = removeKeyListFromData(res2, key_list)
    res3 = removeKeyListFromData(res3, key_list)
    if len(key_list) > 3:
        res4 = removeKeyListFromData(res4, key_list)
    
    # use only word counts > cnum
    res1 = reduceDataList(res1, cnum)
    res2 = reduceDataList(res2, cnum)
    res3 = reduceDataList(res3, cnum)
    if len(key_list) > 3:
        res4 = reduceDataList(res4, cnum)
    
    # remove additional non nouns
    res1 = getNouns(res1)
    res2 = getNouns(res2)
    res3 = getNouns(res3)
    if len(key_list) > 3:
        res4 = getNouns(res4)
    
    # remove paper key words
    res1 = removePaperKeywords(res1)
    res2 = removePaperKeywords(res2)
    res3 = removePaperKeywords(res3)
    if len(key_list) > 3:
        res4 = removePaperKeywords(res4)
    
    
    if len(key_list) > 3:
        return [res1,res2,res3,res4]
    else:
        return [res1,res2,res3]
 
'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: findMiningWords
Input: filepath,file,key_list,cnum = file-path, file-name, keyword list, word count 
Output: dm_cname, dm_cvalue = datamining word and count
description: find the nouns around the keywords

@author: Marcus Landschulze
''' 
def findMiningWords(filepath,file,key_list,cnum):
        
    if len(key_list) > 3:
        [res1,res2,res3,res4] = dataPreProc(filepath+'/texts/'+file,key_list,cnum)
        [dm_cname, dm_cvalue] = calcDataWords(key_list, res1, res2, res3, res4)
    else:
        [res1,res2,res3] = dataPreProc(filepath+'/texts/'+file,key_list,cnum)
        [dm_cname, dm_cvalue] = calcDataWords(key_list,res1, res2, res3)



    return [dm_cname, dm_cvalue]


#-----------------------------------------------------------------------------------------
# ckeck papers
#-----------------------------------------------------------------------------------------

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: res_switch
Input: x = switch value  
Output: x = text string describing importance of the paper
description: return the text string related to x

@author: Marcus Landschulze
'''
def res_switch(x):
    
    return {
            1:'Key paper',
            2:'Important paper',
            3:'Important paper, but not main focus',
            4:'Interesting paper',
            5:'Interesting paper, but not main focus',
            6:'Not a focus paper',
            
            }[x]

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: dataPdf2Txt
Input: file, filepath 
Output: none
description: convert file in filepath to a text-file 

@author: Marcus Landschulze
'''
def dataPdf2Txt(file,filepath):
    
    fhr = open(filepath+'/.work/mining_res_raw.txt','r')
    mining_result = fhr.read()
    mining_result = mining_result.strip()
    mining_result = mining_result.split(' ')
    fhr.close()
        
#    files_pdf = []
    if file.endswith('.pdf'):
#        files_pdf.append(file)
        filename_txt = filepath+'/check/'+file+' '+filepath+'/check/'+file[0:len(file)-4]+'.txt'
        retval = os.system('pdftotext %s'%filename_txt)
        if retval:
            err_code.append('pdftotext returned with error code at file %s'%filename_txt)
        
    return 0

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: dataProcessTxt
Input:  file,filepath, key_list = file-name, file-path, keyword list
Output: kappa_res = resulting kappa values
description: data mining the paper importance using the kappa value

@author: Marcus Landschulze
'''
def dataProcessTxt(file,filepath, key_list):

    kappa_res = []
    
    start_time = time.clock()
    fhr = open(filepath+'/.work/mining_res_raw.txt','r')
    mining_result = fhr.read()
    mining_result = mining_result.strip()
    mining_result = mining_result.split(' ')
    fhr.close()

    fh = open(filepath+'/check/'+file)
    raw = fh.read()
    fh.close()
    raw = raw.lower()
    token = word_tokenize(raw)
    # remove all stopwords -> result is in text
    dm_stopwords = stopwords.words('english') 
    token = [w for w in token if w not in dm_stopwords]
    token = [w for w in token if len(w) >2] # more than 2 charcters
                    
    text = nltk.Text(token)
    data_x = sorted(list(set(text).intersection(mining_result)))
    stop_time = time.clock()
    work_time = stop_time-start_time
    kappa = int((len(data_x)/len(mining_result))*100)
        
    if kappa >= 90: 
        kappa_text = res_switch(1)
    if kappa >= 70 and kappa < 90:
        if len(list(set(data_x).intersection(key_list))) > 0:
            kappa_text = res_switch(2)
        else:
            kappa_text = res_switch(3)
    if kappa >= 50 and kappa < 70: 
        if len(list(set(data_x).intersection(key_list))) > 0:
            kappa_text = res_switch(4)
        else:
            kappa_text = res_switch(5)
    if kappa < 50:
        kappa_text = res_switch(6)
        
    kappa_res.append([kappa_text+' (%d)'%kappa,data_x,file[0:len(file)-4],work_time])
            

    return kappa_res

# text mine paper repo

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: class miningThreadTM
Input:  
Output: 
description: mining thread class for parallel processing 

@author: Marcus Landschulze
'''
class miningThreadTM():
    
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self, file, filepath, key_list):
        self.file = file
        self.filepath = filepath
        self.key_list = key_list
        self.mining_list_count = findMiningWords(filepath, file, key_list, 0)
        return self.mining_list_count
        
    def stop(self):
        return self.mining_list_count

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: mainLoopTM
Input: none 
Output: if len(mining_list_count) > 0 kappa_res, mining_result, stop_time-start_time
        if len(mining_list_count) = 0 kappa_res, key_list, stop_time-start_time
description: main text mining loop

@author: Marcus Landschulze
'''
def mainLoopTM():
    
    num_threads = []
    mining_result = []
    mining_list = []
    dm_result = []
    dm_result_count =[]
    kappa_res = []
    
    
    [filepath,key_list,file_text, pdf2text, browser, pdfreader, project] = readConfigMain()
    while len(key_list) > 4:
        key_list.pop(len(key_list)-1)
    
    mining_result.append(key_list)

    start_time = time.clock()

    # Processing txt-files
    file_list = os.listdir(filepath+'/texts/')
    files = [data.strip() for data in file_list]   
    if len(files) > 0: 
        for t in files:
            thread = miningThreadTM()
            num_threads.append(thread)
#            mining_list_count.append(thread.run(t,filepath,key_list))
            [dm_cname,dm_cvalue] = thread.run(t,filepath,key_list)
            dm_result.append(dm_cname)
            dm_result_count.append(dm_cvalue)
        
    for i in range(0,len(dm_result),1):
        for j in range(0,len(dm_result[i]),1):
            for k in range(0,len(dm_result[i][j]),1):
                mining_list.append(dm_result[i][j][k])
                
    #mining_list = sorted(getNouns(mining_list))
    mining_list_count = Counter(mining_list)
    mining_list_count = mining_list_count.most_common()
#    print(len(num_threads))

# text mining different keywords using the previous result
    if len(mining_list_count) > 0:
        for m in range(4):
            dm_result = []
            dm_result_count =[]
            mining_list = []
        
            
            if len(key_list) > 3:
                keywords = [mining_list_count[0][0],mining_list_count[1][0],mining_list_count[2][0],mining_list_count[3][0]]
                mining_result.append(keywords)
                for t in files:
                    thread = miningThreadTM()
                    num_threads.append(thread)
                    [dm_cname,dm_cvalue] = thread.run(t,filepath,keywords)
                    dm_result.append(dm_cname)
                    dm_result_count.append(dm_cvalue)
                
                    
                for i in range(len(dm_result)):
                    for j in range(len(dm_result[i])):
                        for k in range(len(dm_result[i][j])):
                            mining_list.append(dm_result[i][j][k])
                        
                #mining_list = sorted(getNouns(mining_list))
                mining_list_count = Counter(mining_list)
                mining_list_count = mining_list_count.most_common()

            else:
                keywords = [mining_list_count[0][0],mining_list_count[1][0],mining_list_count[2][0]]
                mining_result.append(keywords)
                for t in files:
                    thread = miningThreadTM()
                    num_threads.append(thread)
                    [dm_cname,dm_cvalue] = thread.run(t,filepath,keywords)
                    dm_result.append(dm_cname)
                    dm_result_count.append(dm_cvalue)
        
                for i in range(0,len(dm_result),1):
                    for j in range(len(dm_result[i])):
                        for k in range(len(dm_result[i][j])):
                            mining_list.append(dm_result[i][j][k])
                            
                #mining_list = sorted(getNouns(mining_list))
                mining_list_count = Counter(mining_list)
                mining_list_count = mining_list_count.most_common()
        
        
        mining_res = []
        for j in range(len(mining_result)):
            mining_res += mining_result[j]
#        for j in range(len(mining_result[i])):
#            mining_res.append(mining_result[i][j])
                
        mining_result = Counter(mining_res)
        mining_result = list(mining_result.keys())
    
        file_list_pdf = os.listdir(filepath+'/pdf/')
        files_pdf = [data.strip() for data in file_list_pdf]
                
        i=0
            
        file_list = os.listdir(filepath+'/texts/')
        files = [data.strip() for data in file_list]
        for t in files:
            fh = open(filepath+'/texts/'+t)
            raw = fh.read()
            fh.close()
            raw = raw.lower()
            token = word_tokenize(raw)
            # remove all stopwords -> result is in text
            dm_stopwords = stopwords.words('english') 
            token = [w for w in token if w not in dm_stopwords]
            token = [w for w in token if len(w) >2] # more than 2 charcters
                
            text = nltk.Text(token)
            data_x = sorted(list(set(text).intersection(mining_result)))
            kappa_res.append([int((len(data_x)/len(mining_result))*100),data_x,files_pdf[i]])
            i=i+1
                
        saveMiningRaw(filepath+'/.work/mining_res_raw.txt', mining_result)
        stop_time = time.clock()

        miningStats(dm_result,filepath,key_list)

        return [kappa_res, mining_result, stop_time-start_time]
    else:
        miningStats(dm_result,filepath,key_list)
        saveMiningRaw(filepath+'/.work/mining_res_raw.txt', key_list)
        stop_time = time.clock()
        return [kappa_res, key_list, stop_time-start_time]

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: miningStats
Input:  dm_result,filepath,key_list = data mining results, file-path, keyword-list
Output: none
description: writing the mining results into a file 

@author: Marcus Landschulze
'''
def miningStats(dm_result,filepath,key_list):
    
    stat1 = []
    stat2 = []
    stat3 = []
    stat4 = []
    stat5 = [] 
    stat6 = []
    
    for i in range(len(dm_result)):
        stat1 += dm_result[i][0]
        stat2 += dm_result[i][1]
        stat3 += dm_result[i][2]
        if len(key_list) > 3:    
            stat4 += dm_result[i][3]
            stat5 += dm_result[i][4]
            stat6 += dm_result[i][5]
    
    stat1_count = Counter(stat1)
    stat2_count = Counter(stat2)
    stat3_count = Counter(stat3)
    if len(key_list) > 3:
        stat4_count = Counter(stat4)
        stat5_count = Counter(stat5)
        stat6_count = Counter(stat6)

    stat1_pcount = list(stat1_count.values())
    pstat1 = list(stat1_count.keys())
    stat2_pcount = list(stat2_count.values())
    pstat2 = list(stat2_count.keys())
    stat3_pcount = list(stat3_count.values())
    pstat3 = list(stat3_count.keys())
    if len(key_list) > 3:
        stat4_pcount = list(stat4_count.values())
        pstat4 = list(stat4_count.keys())
        stat5_pcount = list(stat5_count.values())
        pstat5 = list(stat5_count.keys())
        stat6_pcount = list(stat6_count.values())
        pstat6 = list(stat6_count.keys())
        
    fhw = open(filepath+'/.work/miningStat.txt','w')
    print('%s --> %s\n'%(key_list[0],key_list[1]),file=fhw)
    for i in range(len(stat1_pcount)):
        print(pstat1[i]+',%d'%stat1_pcount[i],file=fhw)
    print('\n%s --> %s\n'%(key_list[0],key_list[2]),file=fhw)
    for i in range(len(stat2_pcount)):
        print(pstat2[i]+',%d'%stat2_pcount[i],file=fhw)
    print('\n%s --> %s\n'%(key_list[1],key_list[2]),file=fhw)
    for i in range(len(stat3_pcount)):
        print(pstat3[i]+',%d'%stat3_pcount[i],file=fhw)
    if len(key_list) > 3:
        print('\n%s --> %s\n'%(key_list[0],key_list[3]),file=fhw)
        for i in range(len(stat4_pcount)):
            print(pstat4[i]+',%d'%stat4_pcount[i],file=fhw)
        print('\n%s --> %s\n'%(key_list[1],key_list[3]),file=fhw)
        for i in range(len(stat5_pcount)):
            print(pstat5[i]+',%d'%stat5_pcount[i],file=fhw)
        print('\n%s --> %s\n'%(key_list[2],key_list[3]),file=fhw)
        for i in range(len(stat6_pcount)):
            print(pstat6[i]+',%d'%stat6_pcount[i],file=fhw)
        print('\n',file=fhw)
    fhw.close()

    
    return 0

# check papers

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: class miningThreadCheck
Input:  
Output: 
description: mining thread class for paper check in the check-folder 

@author: Marcus Landschulze
'''
class miningThreadCheck():
    
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self, file, filepath, key_list, type):
        self.file = file
        self.filepath = filepath
        self.key_list = key_list
        if type == 'pdf':
            dataPdf2Txt(file,filepath)
            return 0
        else:
            self.mining_res = dataProcessTxt(file,filepath,key_list)
            return self.mining_res
        
    def stop(self):
        return self.mining_res

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: mainLoopCheck
Input: none 
Output: mining_res = mining results
description: main loop for text-files in the check-folder

@author: Marcus Landschulze
'''
def mainLoopCheck():
    
    num_threads = []
    mining_res = []
    
    [filepath,key_list,file_text, pdf2text, browser, pdfreader, project] = readConfigMain()
    while len(key_list) > 4:
        key_list.pop(len(key_list)-1)

    
    # Processing pdf-files
    file_list = os.listdir(filepath+'/check/')
    files = [data.strip() for data in file_list]   
    if len(files) > 0: 
        for t in files:
            if t.endswith('.pdf'):
                thread = miningThreadCheck()
                num_threads.append(thread)
                thread.run(t,filepath,key_list,'pdf')
 #       print('pdf: %d'%len(num_threads))

    # Processing txt-files
    file_list = os.listdir(filepath+'/check/')
    files = [data.strip() for data in file_list]   
    if len(files) > 0: 
        for t in files:
            if t.endswith('.txt'):
                thread = miningThreadCheck()
                num_threads.append(thread)
                mining_res.append(thread.run(t,filepath,key_list,'txt'))
#        print('txt: %d'%len(num_threads))
            
    return mining_res



