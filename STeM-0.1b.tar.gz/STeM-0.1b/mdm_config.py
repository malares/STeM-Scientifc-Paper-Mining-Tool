'''
Created on 20.11.2017

@author: Marcus Landschulze
'''

import os


path = '/usr/local/etc'
#path = os.getcwd()

'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: readConfigMain
Input: none 
Output: filepath, key_list, file_text, pdf2text, browser, pdfreader, project
description: read config parameters out of the config-file

@author: Marcus Landschulze
'''
def readConfigMain():
    
    conf = []
    filepath = []
    file_text = []
    key_list = []
    pdf2text = []
    browser = []
    pdfreader = []
    project = []
    
    try:
        fhr = open(path+'/stem_config.cfg','r')
        file_text = fhr.read()
        fhr.close()
    except(FileNotFoundError) as err:
        print('No stem_config.cfg file found. Please check manual\n%s'%err.args[1])
        return 0

    try:
        fhr = open(path+'/stem_config.cfg','r')
        line = fhr.readline()
        while line:
            line = line.strip(' ')
            if line[0] != '#':
                line = line.replace(' ','')
                conf.append(line.split('='))
            line = fhr.readline()
        fhr.close()
    except(FileNotFoundError) as err:
        print('No stem_config.cfg file found. Please check manual\n%s'%err.args[1])
        return 0

    
    for item in conf:
        if item[0] == 'filepath': filepath = item[1].strip('\n')
        if item[0] == 'key_list':
            item[1] = item[1].strip('\n') 
            key_list = item[1].split(',')
        if item[0] == 'pdf2text': pdf2text = item[1].strip('\n')
        if item[0] == 'browser': browser = item[1].strip('\n')
        if item[0] == 'pdfreader': pdfreader = item[1].strip('\n')
        if item[0] == 'project': project = item[1].strip('\n')
        
            
    if len(filepath) > 0 and len(key_list) > 0 and len(pdf2text) > 0 and len(browser) > 0 and len(pdfreader) > 0 and len(project) > 0:
        return [filepath, key_list, file_text, pdf2text, browser, pdfreader, project]
    else:
        return 0
    
'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: saveConfigMain
Input:  text
Output: none
description: saving the config-data into a file 

@author: Marcus Landschulze
'''
def saveConfigMain(text):
    fhw = open(path+'/stem_config.cfg','w')
    fhw.write(text)
    fhw.close()
    config = readConfigMain()
    try:
        os.mkdir('%s/check'%config[0])
        os.mkdir('%s/pdf'%config[0])
        os.mkdir('%s/texts'%config[0])
        os.mkdir('%s/.work'%config[0])
    except(FileExistsError):
        print('Folder already exists')
    return 0
  
'''
Created on 06.11.2017
Version: 0.1 
Revision: 4
Revision date: 15.11.2017
Name: saveConfigMain
Input:  none
Output: help text from file
description: loading help text from file 

@author: Marcus Landschulze
'''
def showHelp():

    fh = open('%s/stem_readme'%path)
    help_text = fh.read()
    fh.close()
    
    return help_text
    
    
