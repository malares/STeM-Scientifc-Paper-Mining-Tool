#!/usr/bin/env python

from distutils.core import setup
import distutils.command.bdist_rpm
import distutils.command.install

setup(name='STeM',
      version='0.1b',
      description='STeM is a text mining tool to help scientists and researchers evaluating new articles in their area of interest.',
      author='Dr. Marcus Landschulze',
      author_email='mala4711@gmail.com',
      url='coming@soon.org',
      py_modules=['mdm_config', 'mdm_dataPreProcess','mdm_gui'],
      scripts=['stem'],
      data_files = [('/usr/local/etc',['stem_config.cfg','stem_readme'])],
      packages = ['nltk','nltk.metrics','nltk.sem','nltk.chunk','nltk.parse','nltk.app','nltk.ccg',
                  'nltk.chat','nltk.classify','nltk.cluster','nltk.corpus','nltk.corpus.reader','nltk.draw','nltk.inference',
                  'nltk.misc','nltk.misc','nltk.sentiment','nltk.stem','nltk.tag','nltk.tbl','nltk.test',
                  'nltk.tokenize','nltk.translate','nltk.twitter'],
      classifiers=[
          'Development Status :: 4 - Beta',
          'Environment :: Console',
          'Environment :: X11 Application :: TKinter',
          'Intended Audience :: End Users/Desktop',
          'Intended Audience :: Developers',
          'Intended Audience :: Science/Research',
          'Intended Audience :: Information Technology'
          'License :: OSI Approved :: Apache Software License',
          'Natural Language :: English'
          'Operating System :: MacOS :: MacOS X',
          'Operating System :: Microsoft :: Windows',
          'Operating System :: POSIX :: Linux',
          'Programming Language :: Python',
          'Topic :: Scientific/Engineering :: Information Analysis',
          ],      
     )
