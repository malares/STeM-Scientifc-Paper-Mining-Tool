#!/usr/bin/env python

from distutils.core import setup
import distutils.command.bdist_rpm
import distutils.command.install

setup(name='STeM',
      version='0.1b',
      description='STeM is a text mining tool to help scientists and researchers evaluating new articles in their area of interest.',
      long_description='STeM is a text mining tool to help scientists and researchers evaluate new papers in their area of interest. The program was born out of a desire to easily analyze scientific papers and to help scientists or researchers to decide whether the paper is interesting or not. The analysis is based on the idea that important nouns exist in the vicinity of the selected keywords and are often used together. A categorical cross-correlation between the nouns can find appropriate new keywords. The resulting data-mining keywords are used to make a prediction about how important any new paper is. A selection of five or six papers is enough to make a prediction. However, the more papers on a topic areavailable, the more accurate the prediction will be.',
      author='Dr. Marcus Landschulze',
      author_email='marlandresearch@gmail.com',
      url='https://github.com/malares/STeM-Scientifc-Paper-Mining-Tool',
      licence='GPL-3.0',
      py_modules=['mdm_config', 'mdm_dataPreProcess','mdm_gui'],
      scripts=['stem'],
      data_files = [('/usr/local/etc',['stem_config.cfg','stem_readme'])],
      packages = ['nltk','nltk.metrics','nltk.sem','nltk.chunk','nltk.parse','nltk.app','nltk.ccg',
                  'nltk.chat','nltk.classify','nltk.cluster','nltk.corpus','nltk.corpus.reader','nltk.draw','nltk.inference',
                  'nltk.misc','nltk.misc','nltk.sentiment','nltk.stem','nltk.tag','nltk.tbl','nltk.test',
                  'nltk.tokenize','nltk.translate','nltk.twitter'],
      classifiers=[
          'Development Status :: 4 - Beta',
          'Environment :: Console',
          'Environment :: X11 Application :: TKinter',
          'Intended Audience :: End Users/Desktop',
          'Intended Audience :: Developers',
          'Intended Audience :: Science/Research',
          'Intended Audience :: Information Technology'
          'License :: OSI Approved :: Apache Software License',
          'Natural Language :: English'
          'Operating System :: MacOS :: MacOS X',
          'Operating System :: Microsoft :: Windows',
          'Operating System :: POSIX :: Linux',
          'Programming Language :: Python',
          'Topic :: Scientific/Engineering :: Information Analysis',
          ],      
     )
